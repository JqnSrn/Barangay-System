@echo off
echo ============================================
echo  Barangay Information System
echo  Starting local server...
echo ============================================
echo.
echo  Open your browser and go to:
echo  http://127.0.0.1:8000
echo.
echo  Press CTRL+C to stop the server.
echo ============================================
python manage.py runserver 127.0.0.1:8000
pause
