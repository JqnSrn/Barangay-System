from django.db import models
# Future: extend with UserProfile for role management
