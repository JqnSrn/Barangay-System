from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from residents.models import AuditLog


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            try:
                AuditLog.objects.create(
                    user=user,
                    action='login',
                    target=f'User: {user.username}',
                    ip_address=request.META.get('REMOTE_ADDR'),
                )
            except Exception:
                pass
            messages.success(
                request, f'Welcome back, {user.first_name or user.username}!')
            return redirect('dashboard')
        else:
            messages.error(
                request, 'Invalid username or password. Please try again.')

    return render(request, 'accounts/login.html')


@login_required
def logout_view(request):
    if request.method == 'POST':
        AuditLog.objects.create(
            user=request.user,
            action='logout',
            target=f'User: {request.user.username}',
            ip_address=request.META.get('REMOTE_ADDR'),
        )
        logout(request)
        messages.info(request, 'You have been logged out.')
    return redirect('login')
