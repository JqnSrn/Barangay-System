@echo off
echo ============================================
echo  Barangay Information System — Setup
echo ============================================

REM Install dependencies
echo.
echo [1/4] Installing required packages...
pip install -r requirements.txt

REM Run migrations
echo.
echo [2/4] Setting up the database...
python manage.py migrate

REM Collect static files
echo.
echo [3/4] Collecting static files...
python manage.py collectstatic --noinput

REM Create superuser prompt
echo.
echo [4/4] Creating admin account...
echo (You will be asked to set a username and password)
python manage.py createsuperuser

echo.
echo ============================================
echo  Setup complete!
echo  Run the system with: run.bat
echo ============================================
pause
