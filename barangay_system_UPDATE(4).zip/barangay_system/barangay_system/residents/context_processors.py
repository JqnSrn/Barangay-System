from residents.models import Resident


def pending_count(request):
    if request.user.is_authenticated:
        count = Resident.objects.filter(status='pending').count()
        return {'pending_count': count}
    return {'pending_count': 0}
