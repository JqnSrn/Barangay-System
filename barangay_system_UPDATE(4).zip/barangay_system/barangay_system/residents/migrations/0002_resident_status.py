from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('residents', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='resident',
            name='status',
            field=models.CharField(
                choices=[('active', 'Active'), ('pending', 'Pending Approval'), ('rejected', 'Rejected')],
                default='active',
                max_length=20,
            ),
        ),
        migrations.AddField(
            model_name='resident',
            name='submitted_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='resident',
            name='reject_reason',
            field=models.TextField(blank=True, default=''),
        ),
        migrations.AlterField(
            model_name='auditlog',
            name='action',
            field=models.CharField(
                choices=[
                    ('create', 'Created'), ('update', 'Updated'), ('delete', 'Archived'),
                    ('view', 'Viewed'), ('login', 'Logged In'), ('logout', 'Logged Out'),
                    ('approve', 'Approved'), ('reject', 'Rejected'), ('restore', 'Restored'),
                ],
                max_length=20,
            ),
        ),
    ]
