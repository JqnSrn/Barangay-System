from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('residents', '0002_resident_status'),
    ]

    operations = [
        # Create Household table
        migrations.CreateModel(
            name='Household',
            fields=[
                ('id',           models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('house_number', models.CharField(blank=True, default='', max_length=20)),
                ('street',       models.CharField(blank=True, default='', max_length=150)),
                ('purok_sitio',  models.CharField(blank=True, default='', max_length=100)),
                ('notes',        models.TextField(blank=True, default='')),
                ('created_at',   models.DateTimeField(auto_now_add=True)),
            ],
            options={'ordering': ['street', 'house_number']},
        ),
        # Add photo to Resident
        migrations.AddField(
            model_name='resident',
            name='photo',
            field=models.ImageField(blank=True, null=True, upload_to='resident_photos/'),
        ),
        # Add household FK to Resident
        migrations.AddField(
            model_name='resident',
            name='household',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='residents',
                to='residents.household',
            ),
        ),
        # Add family_role to Resident
        migrations.AddField(
            model_name='resident',
            name='family_role',
            field=models.CharField(
                blank=True, default='', max_length=20,
                choices=[
                    ('head',        'Head of Family'),
                    ('spouse',      'Spouse'),
                    ('child',       'Child'),
                    ('parent',      'Parent'),
                    ('grandparent', 'Grandparent'),
                    ('sibling',     'Sibling'),
                    ('other',       'Other'),
                ],
                verbose_name='Role in Household',
            ),
        ),
    ]
