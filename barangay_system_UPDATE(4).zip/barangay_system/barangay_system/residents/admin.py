from django.contrib import admin
from .models import Resident, AuditLog


@admin.register(Resident)
class ResidentAdmin(admin.ModelAdmin):
    list_display  = ('full_name', 'age', 'civil_status', 'gender', 'purok_sitio', 'is_voter', 'is_active')
    list_filter   = ('civil_status', 'gender', 'is_voter', 'is_active', 'purok_sitio')
    search_fields = ('first_name', 'last_name', 'middle_name', 'street', 'purok_sitio')
    readonly_fields = ('created_at', 'updated_at', 'created_by', 'updated_by')


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display  = ('user', 'action', 'target', 'timestamp', 'ip_address')
    list_filter   = ('action',)
    readonly_fields = ('user', 'action', 'target', 'timestamp', 'ip_address', 'notes')

    def has_add_permission(self, request):
        return False  # Audit logs should never be manually added

    def has_delete_permission(self, request, obj=None):
        return False  # Audit logs should never be deleted
