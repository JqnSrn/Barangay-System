from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.core.paginator import Paginator
from django.utils import timezone
from datetime import date

from .models import Resident, Household, AuditLog
from .forms import ResidentForm, ResidentSearchForm, ResidentRegistrationForm, HouseholdForm


def get_client_ip(request):
    x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded:
        return x_forwarded.split(',')[0]
    return request.META.get('REMOTE_ADDR')


def log_action(user, action, target='', request=None, notes=''):
    try:
        AuditLog.objects.create(
            user=user, action=action, target=target,
            ip_address=get_client_ip(request) if request else None,
            notes=notes,
        )
    except Exception:
        pass


# ─── DASHBOARD ────────────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    active = Resident.objects.filter(is_active=True, status='active')
    total_residents = active.count()
    total_voters = active.filter(is_voter=True).count()
    male_count = active.filter(gender='male').count()
    female_count = active.filter(gender='female').count()
    recent = active.order_by('-created_at')[:5]
    recent_logs = AuditLog.objects.select_related('user').all()[:10]
    archived_count = Resident.objects.filter(is_active=False).count()
    pending_count = Resident.objects.filter(status='pending').count()
    household_count = Household.objects.count()

    kids_count = sum(1 for r in active if r.age < 18)
    adults_count = sum(1 for r in active if 18 <= r.age < 60)
    seniors_count = sum(1 for r in active if r.age >= 60)

    context = {
        'total_residents': total_residents,
        'total_voters':    total_voters,
        'male_count':      male_count,
        'female_count':    female_count,
        'recent':          recent,
        'recent_logs':     recent_logs,
        'archived_count':  archived_count,
        'pending_count':   pending_count,
        'household_count': household_count,
        'kids_count':      kids_count,
        'adults_count':    adults_count,
        'seniors_count':   seniors_count,
    }
    return render(request, 'residents/dashboard.html', context)


# ─── RESIDENT LIST ─────────────────────────────────────────────────────────────

@login_required
def resident_list(request):
    form = ResidentSearchForm(request.GET)
    residents = Resident.objects.filter(is_active=True, status='active')

    if form.is_valid():
        query = form.cleaned_data.get('query')
        civil_status = form.cleaned_data.get('civil_status')
        gender = form.cleaned_data.get('gender')
        is_voter = form.cleaned_data.get('is_voter')
        age_group = form.cleaned_data.get('age_group')

        if query:
            residents = residents.filter(
                Q(first_name__icontains=query) |
                Q(last_name__icontains=query) |
                Q(middle_name__icontains=query) |
                Q(street__icontains=query) |
                Q(purok_sitio__icontains=query) |
                Q(household__street__icontains=query) |
                Q(household__purok_sitio__icontains=query)
            )
        if civil_status:
            residents = residents.filter(civil_status=civil_status)
        if gender:
            residents = residents.filter(gender=gender)
        if is_voter == '1':
            residents = residents.filter(is_voter=True)
        elif is_voter == '0':
            residents = residents.filter(is_voter=False)

        # Filter by age group
        if age_group:
            residents_list = list(residents)
            if age_group == 'minors':
                residents_list = [r for r in residents_list if r.age < 18]
            elif age_group == 'adults':
                residents_list = [
                    r for r in residents_list if 18 <= r.age < 60]
            elif age_group == 'seniors':
                residents_list = [r for r in residents_list if r.age >= 60]
            residents = Resident.objects.filter(
                pk__in=[r.pk for r in residents_list])

    paginator = Paginator(residents, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'residents/resident_list.html', {
        'form': form, 'page_obj': page_obj, 'total_results': residents.count(),
    })


# ─── RESIDENT DETAIL ───────────────────────────────────────────────────────────

@login_required
def resident_detail(request, pk):
    resident = get_object_or_404(
        Resident, pk=pk, is_active=True, status='active')
    log_action(request.user, 'view', f'Resident: {resident}', request)
    return render(request, 'residents/resident_detail.html', {'resident': resident})


# ─── ADD RESIDENT ──────────────────────────────────────────────────────────────

@login_required
def resident_add(request):
    if request.method == 'POST':
        form = ResidentForm(request.POST, request.FILES)
        if form.is_valid():
            resident = form.save(commit=False)
            resident.created_by = request.user
            resident.updated_by = request.user
            resident.status = 'active'
            resident.save()
            log_action(request.user, 'create',
                       f'Resident: {resident}', request)
            messages.success(
                request, f'Resident "{resident}" has been added successfully.')
            return redirect('resident_detail', pk=resident.pk)
    else:
        form = ResidentForm()
    return render(request, 'residents/resident_form.html', {'form': form, 'action': 'Add'})


# ─── EDIT RESIDENT ─────────────────────────────────────────────────────────────

@login_required
def resident_edit(request, pk):
    resident = get_object_or_404(
        Resident, pk=pk, is_active=True, status='active')
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'You do not have permission to edit records.')
        return redirect('resident_detail', pk=pk)

    if request.method == 'POST':
        form = ResidentForm(request.POST, request.FILES, instance=resident)
        if form.is_valid():
            updated = form.save(commit=False)
            updated.updated_by = request.user
            updated.save()
            log_action(request.user, 'update',
                       f'Resident: {resident}', request)
            messages.success(
                request, f'Resident "{resident}" has been updated.')
            return redirect('resident_detail', pk=resident.pk)
    else:
        form = ResidentForm(instance=resident)

    return render(request, 'residents/resident_form.html', {
        'form': form, 'action': 'Edit', 'resident': resident,
    })


# ─── ARCHIVE ──────────────────────────────────────────────────────────────────

@login_required
def resident_archive(request, pk):
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(
            request, 'You do not have permission to archive records.')
        return redirect('resident_detail', pk=pk)
    resident = get_object_or_404(Resident, pk=pk, is_active=True)
    if request.method == 'POST':
        reason = request.POST.get('reason', '').strip()
        name = str(resident)
        resident.is_active = False
        resident.updated_by = request.user
        resident.save()
        log_action(request.user, 'delete', f'Archived: {name}', request,
                   notes=f'Reason: {reason}' if reason else 'No reason given')
        messages.success(request, f'Resident "{name}" has been archived.')
        return redirect('resident_list')
    return render(request, 'residents/resident_confirm_archive.html', {'resident': resident})


# ─── ARCHIVED LIST ────────────────────────────────────────────────────────────

@login_required
def archived_list(request):
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(
            request, 'You do not have permission to view archived records.')
        return redirect('resident_list')
    archived = Resident.objects.filter(is_active=False).order_by('-updated_at')
    archived_with_logs = []
    for r in archived:
        log = AuditLog.objects.filter(target__icontains=str(
            r), action='delete').order_by('-timestamp').first()
        archived_with_logs.append((r, log))
    paginator = Paginator(archived_with_logs, 15)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'residents/archived_list.html', {
        'page_obj': page_obj, 'total': archived.count(),
    })


# ─── RESTORE ──────────────────────────────────────────────────────────────────

@login_required
def resident_restore(request, pk):
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(
            request, 'You do not have permission to restore records.')
        return redirect('archived_list')
    resident = get_object_or_404(Resident, pk=pk, is_active=False)
    if request.method == 'POST':
        name = str(resident)
        resident.is_active = True
        resident.updated_by = request.user
        resident.save()
        log_action(request.user, 'restore', f'Restored: {name}', request)
        messages.success(request, f'Resident "{name}" has been restored.')
        return redirect('resident_detail', pk=resident.pk)
    return render(request, 'residents/resident_confirm_restore.html', {'resident': resident})


# ─── PUBLIC REGISTRATION ──────────────────────────────────────────────────────

def resident_register(request):
    if request.method == 'POST':
        form = ResidentRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            resident = form.save(commit=False)
            resident.status = 'pending'
            resident.is_active = True
            resident.submitted_at = timezone.now()
            resident.save()
            return redirect('register_success')
    else:
        form = ResidentRegistrationForm()
    return render(request, 'residents/register.html', {'form': form})


def register_success(request):
    return render(request, 'residents/register_success.html')


# ─── PENDING APPROVALS ────────────────────────────────────────────────────────

@login_required
def pending_list(request):
    pending = Resident.objects.filter(
        status='pending').order_by('-submitted_at')
    rejected = Resident.objects.filter(
        status='rejected').order_by('-updated_at')
    paginator = Paginator(pending, 15)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'residents/pending_list.html', {
        'page_obj': page_obj, 'pending_count': pending.count(), 'rejected': rejected,
    })


@login_required
def resident_approve(request, pk):
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(
            request, 'You do not have permission to approve records.')
        return redirect('pending_list')
    resident = get_object_or_404(Resident, pk=pk, status='pending')
    if request.method == 'POST':
        resident.status = 'active'
        resident.updated_by = request.user
        resident.save()
        log_action(request.user, 'approve', f'Approved: {resident}', request)
        messages.success(request, f'"{resident}" has been approved.')
        return redirect('pending_list')
    return render(request, 'residents/resident_confirm_approve.html', {'resident': resident})


@login_required
def resident_reject(request, pk):
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(
            request, 'You do not have permission to reject records.')
        return redirect('pending_list')
    resident = get_object_or_404(Resident, pk=pk, status='pending')
    if request.method == 'POST':
        reason = request.POST.get('reason', '').strip()
        resident.status = 'rejected'
        resident.reject_reason = reason
        resident.updated_by = request.user
        resident.save()
        log_action(request.user, 'reject', f'Rejected: {resident}', request,
                   notes=f'Reason: {reason}' if reason else 'No reason given')
        messages.warning(
            request, f'"{resident}" submission has been rejected.')
        return redirect('pending_list')
    return render(request, 'residents/resident_confirm_reject.html', {'resident': resident})


# ─── HOUSEHOLDS ───────────────────────────────────────────────────────────────

@login_required
def household_list(request):
    query = request.GET.get('q', '')
    households = Household.objects.all()
    if query:
        households = households.filter(
            Q(street__icontains=query) |
            Q(purok_sitio__icontains=query) |
            Q(house_number__icontains=query)
        )
    paginator = Paginator(households, 15)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'residents/household_list.html', {
        'page_obj': page_obj, 'query': query, 'total': households.count(),
    })


@login_required
def household_detail(request, pk):
    household = get_object_or_404(Household, pk=pk)
    members = household.residents.filter(
        is_active=True, status='active').order_by('family_role', 'last_name')
    return render(request, 'residents/household_detail.html', {
        'household': household, 'members': members,
    })


@login_required
def household_add(request):
    if request.method == 'POST':
        form = HouseholdForm(request.POST)
        if form.is_valid():
            household = form.save()
            messages.success(
                request, f'Household at "{household}" has been created.')
            return redirect('household_detail', pk=household.pk)
    else:
        form = HouseholdForm()
    return render(request, 'residents/household_form.html', {'form': form, 'action': 'Add'})


@login_required
def household_edit(request, pk):
    household = get_object_or_404(Household, pk=pk)
    if request.method == 'POST':
        form = HouseholdForm(request.POST, instance=household)
        if form.is_valid():
            form.save()
            messages.success(request, 'Household updated.')
            return redirect('household_detail', pk=household.pk)
    else:
        form = HouseholdForm(instance=household)
    return render(request, 'residents/household_form.html', {
        'form': form, 'action': 'Edit', 'household': household,
    })


# ─── PRINT VIEWS ──────────────────────────────────────────────────────────────

@login_required
def print_clearance(request, pk):
    resident = get_object_or_404(
        Resident, pk=pk, is_active=True, status='active')
    log_action(request.user, 'view', f'Printed Clearance: {resident}', request)
    return render(request, 'residents/print_clearance.html', {
        'resident': resident,
        'issue_date': date.today().strftime('%B %d, %Y'),
        'print_date': date.today().strftime('%B %d, %Y'),
    })


@login_required
def print_resident_info(request, pk):
    resident = get_object_or_404(
        Resident, pk=pk, is_active=True, status='active')
    log_action(request.user, 'view',
               f'Printed Info Sheet: {resident}', request)
    return render(request, 'residents/print_resident_info.html', {
        'resident': resident, 'print_date': date.today().strftime('%B %d, %Y'),
    })


@login_required
def print_resident_list(request):
    residents = Resident.objects.filter(
        is_active=True, status='active').order_by('last_name', 'first_name')
    age_group = request.GET.get('age_group', '')

    # Filter by age group if provided
    if age_group:
        residents_list = list(residents)
        if age_group == 'minors':
            residents_list = [r for r in residents_list if r.age < 18]
            title_suffix = ' - Minors (0–17)'
        elif age_group == 'adults':
            residents_list = [r for r in residents_list if 18 <= r.age < 60]
            title_suffix = ' - Adults (18–59)'
        elif age_group == 'seniors':
            residents_list = [r for r in residents_list if r.age >= 60]
            title_suffix = ' - Senior Citizens (60+)'
        else:
            title_suffix = ''
        residents = Resident.objects.filter(
            pk__in=[r.pk for r in residents_list])
    else:
        title_suffix = ''

    voter_count = residents.filter(is_voter=True).count()
    male_count = residents.filter(gender='male').count()
    female_count = residents.filter(gender='female').count()
    log_action(request.user, 'view',
               f'Printed Master Resident List{title_suffix}', request)
    return render(request, 'residents/print_resident_list.html', {
        'residents':    residents,
        'voter_count':  voter_count,
        'male_count':   male_count,
        'female_count': female_count,
        'print_date':   date.today().strftime('%B %d, %Y'),
        'printed_by':   request.user.get_full_name() or request.user.username,
        'title_suffix': title_suffix,
    })


@login_required
def print_certificate(request, pk, cert_type='indigency'):
    """
    Print different types of certificates.
    cert_type: 'indigency', 'financial', 'medical', 'legal'
    """
    resident = get_object_or_404(
        Resident, pk=pk, is_active=True, status='active')

    cert_types = {
        'indigency': 'Certificate of Indigency',
        'financial': 'Certificate of Indigency - Financial',
        'medical': 'Certificate of Indigency - Medical',
        'legal': 'Certificate of Indigency - Legal',
    }

    cert_title = cert_types.get(cert_type, 'Certificate of Indigency')
    log_action(request.user, 'view',
               f'Printed {cert_title}: {resident}', request)

    return render(request, 'residents/print_certificate.html', {
        'resident': resident,
        'cert_type': cert_type,
        'cert_title': cert_title,
        'issue_date': date.today().strftime('%B %d, %Y'),
        'print_date': date.today().strftime('%B %d, %Y'),
    })
