from django.db import models
from django.contrib.auth.models import User
from datetime import date


class Household(models.Model):
    """Represents one physical household/family unit in the barangay."""
    house_number = models.CharField(max_length=20, blank=True, default='')
    street       = models.CharField(max_length=150, blank=True, default='')
    purok_sitio  = models.CharField(max_length=100, blank=True, default='')
    notes        = models.TextField(blank=True, default='', help_text='Optional notes about this household')
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['street', 'house_number']

    def __str__(self):
        parts = []
        if self.house_number:
            parts.append(self.house_number)
        if self.street:
            parts.append(self.street)
        if self.purok_sitio:
            parts.append(self.purok_sitio)
        return ', '.join(parts) if parts else f'Household #{self.pk}'

    @property
    def full_address(self):
        return str(self)

    @property
    def member_count(self):
        return self.residents.filter(is_active=True, status='active').count()

    @property
    def head(self):
        return self.residents.filter(family_role='head', is_active=True).first()


class Resident(models.Model):
    CIVIL_STATUS_CHOICES = [
        ('single',    'Single'),
        ('married',   'Married'),
        ('widowed',   'Widowed'),
        ('separated', 'Separated'),
        ('annulled',  'Annulled'),
    ]

    GENDER_CHOICES = [
        ('male',   'Male'),
        ('female', 'Female'),
    ]

    SUFFIX_CHOICES = [
        ('',    'None'),
        ('Jr.', 'Jr.'),
        ('Sr.', 'Sr.'),
        ('II',  'II'),
        ('III', 'III'),
        ('IV',  'IV'),
    ]

    STATUS_CHOICES = [
        ('active',   'Active'),
        ('pending',  'Pending Approval'),
        ('rejected', 'Rejected'),
    ]

    FAMILY_ROLE_CHOICES = [
        ('head',        'Head of Family'),
        ('spouse',      'Spouse'),
        ('child',       'Child'),
        ('parent',      'Parent'),
        ('grandparent', 'Grandparent'),
        ('sibling',     'Sibling'),
        ('other',       'Other'),
    ]

    # Name fields
    first_name  = models.CharField(max_length=100)
    middle_name = models.CharField(max_length=100, blank=True, default='')
    last_name   = models.CharField(max_length=100)
    suffix      = models.CharField(max_length=10, choices=SUFFIX_CHOICES, blank=True, default='')

    # Profile photo
    photo = models.ImageField(upload_to='resident_photos/', blank=True, null=True)

    # Personal info
    date_of_birth  = models.DateField()
    gender         = models.CharField(max_length=10, choices=GENDER_CHOICES)
    civil_status   = models.CharField(max_length=20, choices=CIVIL_STATUS_CHOICES)
    contact_number = models.CharField(max_length=15, blank=True, default='')

    # Address (kept for standalone/manual entry)
    house_number = models.CharField(max_length=20, blank=True, default='')
    street       = models.CharField(max_length=150, blank=True, default='')
    purok_sitio  = models.CharField(max_length=100, blank=True, default='')

    # Household link
    household   = models.ForeignKey(
        Household, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='residents'
    )
    family_role = models.CharField(
        max_length=20, choices=FAMILY_ROLE_CHOICES,
        blank=True, default='',
        verbose_name='Role in Household'
    )

    # Status flags
    is_voter  = models.BooleanField(default=False, verbose_name='Registered Voter')
    is_active = models.BooleanField(default=True,  verbose_name='Active Record')

    # Approval status
    status        = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    submitted_at  = models.DateTimeField(null=True, blank=True)
    reject_reason = models.TextField(blank=True, default='')

    # Audit fields
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='residents_created')
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='residents_updated')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['last_name', 'first_name']

    def __str__(self):
        parts = [self.first_name]
        if self.middle_name:
            parts.append(self.middle_name[0] + '.')
        parts.append(self.last_name)
        if self.suffix:
            parts.append(self.suffix)
        return ' '.join(parts)

    @property
    def age(self):
        today = date.today()
        dob   = self.date_of_birth
        return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))

    @property
    def full_name(self):
        parts = [self.last_name + ',', self.first_name]
        if self.middle_name:
            parts.append(self.middle_name)
        if self.suffix:
            parts.append(self.suffix)
        return ' '.join(parts)

    @property
    def full_address(self):
        # Use household address if linked, else use individual fields
        if self.household:
            return self.household.full_address
        parts = []
        if self.house_number:
            parts.append(self.house_number)
        if self.street:
            parts.append(self.street)
        if self.purok_sitio:
            parts.append(self.purok_sitio)
        return ', '.join(parts) if parts else '—'

    @property
    def household_members(self):
        if self.household:
            return self.household.residents.filter(is_active=True, status='active').exclude(pk=self.pk)
        return Resident.objects.none()

    @property
    def initials(self):
        return (self.first_name[0] + self.last_name[0]).upper() if self.first_name and self.last_name else '?'


class AuditLog(models.Model):
    ACTION_CHOICES = [
        ('create',  'Created'),
        ('update',  'Updated'),
        ('delete',  'Archived'),
        ('view',    'Viewed'),
        ('login',   'Logged In'),
        ('logout',  'Logged Out'),
        ('approve', 'Approved'),
        ('reject',  'Rejected'),
        ('restore', 'Restored'),
    ]

    user       = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    action     = models.CharField(max_length=20, choices=ACTION_CHOICES)
    target     = models.CharField(max_length=200, blank=True)
    timestamp  = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    notes      = models.TextField(blank=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.user} — {self.action} — {self.timestamp:%Y-%m-%d %H:%M}"
