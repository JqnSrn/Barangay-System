from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count
from django.core.paginator import Paginator
from datetime import date

from .models import Resident, AuditLog
from .forms import ResidentForm, ResidentSearchForm


def get_client_ip(request):
    """Extract client IP address for audit logging."""
    x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded:
        return x_forwarded.split(',')[0]
    return request.META.get('REMOTE_ADDR')


def log_action(user, action, target='', request=None, notes=''):
    """Helper to create an audit log entry."""
    try:
        AuditLog.objects.create(
            user=user,
            action=action,
            target=target,
            ip_address=get_client_ip(request) if request else None,
            notes=notes,
        )
    except Exception:
        pass


# ─── DASHBOARD ────────────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    total_residents = Resident.objects.filter(is_active=True).count()
    total_voters    = Resident.objects.filter(is_active=True, is_voter=True).count()
    male_count      = Resident.objects.filter(is_active=True, gender='male').count()
    female_count    = Resident.objects.filter(is_active=True, gender='female').count()
    recent          = Resident.objects.filter(is_active=True).order_by('-created_at')[:5]
    recent_logs     = AuditLog.objects.select_related('user').all()[:10]

    context = {
        'total_residents': total_residents,
        'total_voters':    total_voters,
        'male_count':      male_count,
        'female_count':    female_count,
        'recent':          recent,
        'recent_logs':     recent_logs,
    }
    return render(request, 'residents/dashboard.html', context)


# ─── RESIDENT LIST ─────────────────────────────────────────────────────────────

@login_required
def resident_list(request):
    form = ResidentSearchForm(request.GET)
    residents = Resident.objects.filter(is_active=True)

    if form.is_valid():
        query = form.cleaned_data.get('query')
        civil_status = form.cleaned_data.get('civil_status')
        gender = form.cleaned_data.get('gender')
        is_voter = form.cleaned_data.get('is_voter')

        if query:
            residents = residents.filter(
                Q(first_name__icontains=query) |
                Q(last_name__icontains=query) |
                Q(middle_name__icontains=query) |
                Q(street__icontains=query) |
                Q(purok_sitio__icontains=query)
            )
        if civil_status:
            residents = residents.filter(civil_status=civil_status)
        if gender:
            residents = residents.filter(gender=gender)
        if is_voter == '1':
            residents = residents.filter(is_voter=True)
        elif is_voter == '0':
            residents = residents.filter(is_voter=False)

    paginator = Paginator(residents, 15)  # 15 per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'form': form,
        'page_obj': page_obj,
        'total_results': residents.count(),
    }
    return render(request, 'residents/resident_list.html', context)


# ─── RESIDENT DETAIL ───────────────────────────────────────────────────────────

@login_required
def resident_detail(request, pk):
    resident = get_object_or_404(Resident, pk=pk, is_active=True)
    log_action(request.user, 'view', f'Resident: {resident}', request)
    return render(request, 'residents/resident_detail.html', {'resident': resident})


# ─── ADD RESIDENT ──────────────────────────────────────────────────────────────

@login_required
def resident_add(request):
    if request.method == 'POST':
        form = ResidentForm(request.POST)
        if form.is_valid():
            resident = form.save(commit=False)
            resident.created_by = request.user
            resident.updated_by = request.user
            resident.save()
            log_action(request.user, 'create', f'Resident: {resident}', request)
            messages.success(request, f'Resident "{resident}" has been added successfully.')
            return redirect('resident_detail', pk=resident.pk)
    else:
        form = ResidentForm()

    return render(request, 'residents/resident_form.html', {'form': form, 'action': 'Add'})


# ─── EDIT RESIDENT ─────────────────────────────────────────────────────────────

@login_required
def resident_edit(request, pk):
    resident = get_object_or_404(Resident, pk=pk, is_active=True)

    # Encoders and Admins can edit; viewers cannot
    if not (request.user.is_staff or hasattr(request.user, 'profile') and request.user.profile.role in ['admin', 'encoder']):
        if not request.user.is_superuser:
            messages.error(request, 'You do not have permission to edit records.')
            return redirect('resident_detail', pk=pk)

    if request.method == 'POST':
        form = ResidentForm(request.POST, instance=resident)
        if form.is_valid():
            updated = form.save(commit=False)
            updated.updated_by = request.user
            updated.save()
            log_action(request.user, 'update', f'Resident: {resident}', request)
            messages.success(request, f'Resident "{resident}" has been updated.')
            return redirect('resident_detail', pk=resident.pk)
    else:
        form = ResidentForm(instance=resident)

    return render(request, 'residents/resident_form.html', {
        'form': form,
        'action': 'Edit',
        'resident': resident,
    })


# ─── DELETE RESIDENT (soft delete) ────────────────────────────────────────────

@login_required
def resident_delete(request, pk):
    # Only admins/superusers can delete
    if not request.user.is_superuser and not request.user.is_staff:
        messages.error(request, 'You do not have permission to delete records.')
        return redirect('resident_detail', pk=pk)

    resident = get_object_or_404(Resident, pk=pk)

    if request.method == 'POST':
        name = str(resident)
        resident.is_active = False  # soft delete — record is kept in DB
        resident.save()
        log_action(request.user, 'delete', f'Resident: {name}', request)
        messages.success(request, f'Resident "{name}" has been removed from the active list.')
        return redirect('resident_list')

    return render(request, 'residents/resident_confirm_delete.html', {'resident': resident})


# ─── PRINT: BARANGAY CLEARANCE ────────────────────────────────────────────────

@login_required
def print_clearance(request, pk):
    resident = get_object_or_404(Resident, pk=pk, is_active=True)
    log_action(request.user, 'view', f'Printed Clearance: {resident}', request)
    context = {
        'resident':   resident,
        'issue_date': date.today().strftime('%B %d, %Y'),
        'print_date': date.today().strftime('%B %d, %Y'),
    }
    return render(request, 'residents/print_clearance.html', context)


# ─── PRINT: RESIDENT INFO SHEET ───────────────────────────────────────────────

@login_required
def print_resident_info(request, pk):
    resident = get_object_or_404(Resident, pk=pk, is_active=True)
    log_action(request.user, 'view', f'Printed Info Sheet: {resident}', request)
    context = {
        'resident':   resident,
        'print_date': date.today().strftime('%B %d, %Y'),
    }
    return render(request, 'residents/print_resident_info.html', context)


# ─── PRINT: FULL RESIDENT LIST ────────────────────────────────────────────────

@login_required
def print_resident_list(request):
    residents    = Resident.objects.filter(is_active=True).order_by('last_name', 'first_name')
    voter_count  = residents.filter(is_voter=True).count()
    male_count   = residents.filter(gender='male').count()
    female_count = residents.filter(gender='female').count()
    log_action(request.user, 'view', 'Printed Master Resident List', request)
    context = {
        'residents':    residents,
        'voter_count':  voter_count,
        'male_count':   male_count,
        'female_count': female_count,
        'print_date':   date.today().strftime('%B %d, %Y'),
        'printed_by':   request.user.get_full_name() or request.user.username,
    }
    return render(request, 'residents/print_resident_list.html', context)
