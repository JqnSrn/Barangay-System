from django.db import models
from django.contrib.auth.models import User
from datetime import date


class Resident(models.Model):
    CIVIL_STATUS_CHOICES = [
        ('single', 'Single'),
        ('married', 'Married'),
        ('widowed', 'Widowed'),
        ('separated', 'Separated'),
        ('annulled', 'Annulled'),
    ]

    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
    ]

    SUFFIX_CHOICES = [
        ('', 'None'),
        ('Jr.', 'Jr.'),
        ('Sr.', 'Sr.'),
        ('II', 'II'),
        ('III', 'III'),
        ('IV', 'IV'),
    ]

    # Name fields
    first_name   = models.CharField(max_length=100)
    middle_name  = models.CharField(max_length=100, blank=True, default='')
    last_name    = models.CharField(max_length=100)
    suffix       = models.CharField(max_length=10, choices=SUFFIX_CHOICES, blank=True, default='')

    # Personal info
    date_of_birth = models.DateField()
    gender        = models.CharField(max_length=10, choices=GENDER_CHOICES)
    civil_status  = models.CharField(max_length=20, choices=CIVIL_STATUS_CHOICES)
    contact_number = models.CharField(max_length=15, blank=True, default='')

    # Address
    house_number  = models.CharField(max_length=20, blank=True, default='')
    street        = models.CharField(max_length=150, blank=True, default='')
    purok_sitio   = models.CharField(max_length=100, blank=True, default='')

    # Status flags
    is_voter      = models.BooleanField(default=False, verbose_name='Registered Voter')
    is_active     = models.BooleanField(default=True, verbose_name='Active Record')

    # Audit fields
    created_by    = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='residents_created')
    updated_by    = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='residents_updated')
    created_at    = models.DateTimeField(auto_now_add=True)
    updated_at    = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['last_name', 'first_name']

    def __str__(self):
        parts = [self.first_name]
        if self.middle_name:
            parts.append(self.middle_name[0] + '.')
        parts.append(self.last_name)
        if self.suffix:
            parts.append(self.suffix)
        return ' '.join(parts)

    @property
    def age(self):
        """Auto-calculate age from date of birth."""
        today = date.today()
        dob = self.date_of_birth
        return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))

    @property
    def full_name(self):
        parts = [self.last_name + ',', self.first_name]
        if self.middle_name:
            parts.append(self.middle_name)
        if self.suffix:
            parts.append(self.suffix)
        return ' '.join(parts)

    @property
    def full_address(self):
        parts = []
        if self.house_number:
            parts.append(self.house_number)
        if self.street:
            parts.append(self.street)
        if self.purok_sitio:
            parts.append(self.purok_sitio)
        return ', '.join(parts) if parts else '—'


class AuditLog(models.Model):
    ACTION_CHOICES = [
        ('create', 'Created'),
        ('update', 'Updated'),
        ('delete', 'Deleted'),
        ('view',   'Viewed'),
        ('login',  'Logged In'),
        ('logout', 'Logged Out'),
    ]

    user       = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    action     = models.CharField(max_length=20, choices=ACTION_CHOICES)
    target     = models.CharField(max_length=200, blank=True)  # e.g. "Resident: Juan dela Cruz"
    timestamp  = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    notes      = models.TextField(blank=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.user} — {self.action} — {self.timestamp:%Y-%m-%d %H:%M}"
