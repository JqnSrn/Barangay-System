from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('residents/', views.resident_list, name='resident_list'),
    path('residents/add/', views.resident_add, name='resident_add'),
    path('residents/<int:pk>/', views.resident_detail, name='resident_detail'),
    path('residents/<int:pk>/edit/', views.resident_edit, name='resident_edit'),
    path('residents/<int:pk>/delete/', views.resident_delete, name='resident_delete'),
    # Print URLs
    path('residents/<int:pk>/print/clearance/', views.print_clearance, name='print_clearance'),
    path('residents/<int:pk>/print/info/', views.print_resident_info, name='print_resident_info'),
    path('residents/print/list/', views.print_resident_list, name='print_resident_list'),
]
