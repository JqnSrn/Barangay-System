from django import forms
from .models import Resident


class ResidentForm(forms.ModelForm):
    date_of_birth = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        label='Date of Birth'
    )

    class Meta:
        model = Resident
        fields = [
            'first_name', 'middle_name', 'last_name', 'suffix',
            'date_of_birth', 'gender', 'civil_status', 'contact_number',
            'house_number', 'street', 'purok_sitio',
            'is_voter',
        ]
        widgets = {
            'first_name':      forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Juan'}),
            'middle_name':     forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Optional'}),
            'last_name':       forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. dela Cruz'}),
            'suffix':          forms.Select(attrs={'class': 'form-select'}),
            'gender':          forms.Select(attrs={'class': 'form-select'}),
            'civil_status':    forms.Select(attrs={'class': 'form-select'}),
            'contact_number':  forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 09171234567'}),
            'house_number':    forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 12'}),
            'street':          forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Rizal St.'}),
            'purok_sitio':     forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Purok 3'}),
            'is_voter':        forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
        labels = {
            'house_number': 'House No.',
            'purok_sitio':  'Purok / Sitio',
            'is_voter':     'Registered Voter?',
        }

    def clean_first_name(self):
        return self.cleaned_data['first_name'].strip().title()

    def clean_last_name(self):
        return self.cleaned_data['last_name'].strip().title()

    def clean_middle_name(self):
        return self.cleaned_data['middle_name'].strip().title()


class ResidentSearchForm(forms.Form):
    query = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search by name, address, or purok...',
        })
    )
    civil_status = forms.ChoiceField(
        required=False,
        choices=[('', 'All Civil Status')] + Resident.CIVIL_STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    gender = forms.ChoiceField(
        required=False,
        choices=[('', 'All Genders')] + Resident.GENDER_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    is_voter = forms.ChoiceField(
        required=False,
        choices=[('', 'All'), ('1', 'Voters Only'), ('0', 'Non-voters')],
        widget=forms.Select(attrs={'class': 'form-select'})
    )
