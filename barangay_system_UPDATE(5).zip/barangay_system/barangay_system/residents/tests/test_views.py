from datetime import date

from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import reverse

from residents.models import AuditLog, Household, Resident


def _resident_form_data(**overrides):
    data = {
        'first_name': 'Maria',
        'middle_name': '',
        'last_name': 'Garcia',
        'suffix': '',
        'date_of_birth': '1995-06-15',
        'gender': 'female',
        'civil_status': 'single',
        'contact_number': '',
        'house_number': '',
        'street': '',
        'purok_sitio': '',
        'household': '',
        'family_role': '',
        'is_voter': '',
    }
    data.update(overrides)
    return data


def _registration_form_data(**overrides):
    data = {
        'first_name': 'Pedro',
        'middle_name': '',
        'last_name': 'Reyes',
        'suffix': '',
        'date_of_birth': '2001-01-20',
        'gender': 'male',
        'civil_status': 'single',
        'contact_number': '',
        'house_number': '1',
        'street': 'Test Rd',
        'purok_sitio': '',
        'is_voter': '',
    }
    data.update(overrides)
    return data


class ResidentViewsAuthTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(
            username='staffer',
            password='securepass123',
            is_staff=True,
        )
        self.plain = User.objects.create_user(
            username='viewer',
            password='securepass123',
            is_staff=False,
        )

    def test_dashboard_redirects_when_anonymous(self):
        r = self.client.get(reverse('dashboard'))
        self.assertEqual(r.status_code, 302)
        self.assertIn(reverse('login'), r.url)

    def test_dashboard_renders_when_logged_in(self):
        self.client.login(username='staffer', password='securepass123')
        r = self.client.get(reverse('dashboard'))
        self.assertEqual(r.status_code, 200)

    def test_resident_list_requires_login(self):
        r = self.client.get(reverse('resident_list'))
        self.assertEqual(r.status_code, 302)


class ResidentCRUDAndPermissionsTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.staff = User.objects.create_user(
            username='adminuser',
            password='securepass123',
            is_staff=True,
        )
        self.resident = Resident.objects.create(
            first_name='Luis',
            last_name='Torres',
            date_of_birth=date(1988, 4, 4),
            gender='male',
            civil_status='single',
            status='active',
            is_active=True,
            created_by=self.staff,
        )

    def test_resident_detail_active(self):
        self.client.login(username='adminuser', password='securepass123')
        r = self.client.get(reverse('resident_detail', args=[self.resident.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertTrue(
            AuditLog.objects.filter(
                action='view', user=self.staff
            ).exists()
        )

    def test_resident_add_creates_active_resident(self):
        self.client.login(username='adminuser', password='securepass123')
        r = self.client.post(
            reverse('resident_add'),
            _resident_form_data(
                first_name='New',
                last_name='Person',
                date_of_birth='1999-12-31',
            ),
        )
        self.assertEqual(r.status_code, 302)
        created = Resident.objects.get(last_name='Person')
        self.assertEqual(created.status, 'active')
        self.assertEqual(created.created_by, self.staff)

    def test_non_staff_cannot_edit_get_redirect(self):
        User.objects.create_user(
            username='noview',
            password='securepass123',
            is_staff=False,
        )
        self.client.login(username='noview', password='securepass123')
        r = self.client.get(reverse('resident_edit', args=[self.resident.pk]))
        self.assertRedirects(r, reverse('resident_detail', args=[self.resident.pk]))

    def test_staff_can_edit(self):
        self.client.login(username='adminuser', password='securepass123')
        r = self.client.get(reverse('resident_edit', args=[self.resident.pk]))
        self.assertEqual(r.status_code, 200)

    def test_archive_post_sets_inactive(self):
        self.client.login(username='adminuser', password='securepass123')
        r = self.client.post(
            reverse('resident_archive', args=[self.resident.pk]),
            {'reason': 'Moved out'},
        )
        self.assertEqual(r.status_code, 302)
        self.resident.refresh_from_db()
        self.assertFalse(self.resident.is_active)

    def test_non_staff_archive_redirects_without_change(self):
        viewer = User.objects.create_user(
            username='v2',
            password='securepass123',
            is_staff=False,
        )
        self.client.login(username='v2', password='securepass123')
        r = self.client.post(
            reverse('resident_archive', args=[self.resident.pk]),
            {'reason': 'x'},
        )
        self.assertEqual(r.status_code, 302)
        self.resident.refresh_from_db()
        self.assertTrue(self.resident.is_active)

    def test_restore_brings_resident_back(self):
        self.resident.is_active = False
        self.resident.save()
        self.client.login(username='adminuser', password='securepass123')
        r = self.client.post(reverse('resident_restore', args=[self.resident.pk]))
        self.assertEqual(r.status_code, 302)
        self.resident.refresh_from_db()
        self.assertTrue(self.resident.is_active)


class PendingApprovalTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.staff = User.objects.create_user(
            username='approver',
            password='securepass123',
            is_staff=True,
        )
        self.pending = Resident.objects.create(
            first_name='Wait',
            last_name='Listed',
            date_of_birth=date(2005, 5, 5),
            gender='female',
            civil_status='single',
            status='pending',
            is_active=True,
        )

    def test_public_register_creates_pending(self):
        r = self.client.post(
            reverse('resident_register'),
            _registration_form_data(
                first_name='Public',
                last_name='Applicant',
            ),
        )
        self.assertRedirects(r, reverse('register_success'))
        app = Resident.objects.get(last_name='Applicant')
        self.assertEqual(app.status, 'pending')

    def test_register_success_anonymous_ok(self):
        r = self.client.get(reverse('register_success'))
        self.assertEqual(r.status_code, 200)

    def test_approve_post(self):
        self.client.login(username='approver', password='securepass123')
        r = self.client.post(
            reverse('resident_approve', args=[self.pending.pk]),
        )
        self.assertEqual(r.status_code, 302)
        self.pending.refresh_from_db()
        self.assertEqual(self.pending.status, 'active')

    def test_reject_post(self):
        self.client.login(username='approver', password='securepass123')
        r = self.client.post(
            reverse('resident_reject', args=[self.pending.pk]),
            {'reason': 'Incomplete docs'},
        )
        self.assertEqual(r.status_code, 302)
        self.pending.refresh_from_db()
        self.assertEqual(self.pending.status, 'rejected')
        self.assertIn('Incomplete', self.pending.reject_reason)


class HouseholdViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(
            username='hhuser',
            password='securepass123',
        )
        self.hh = Household.objects.create(
            house_number='7',
            street='Laguna St.',
        )

    def test_household_list_and_detail(self):
        self.client.login(username='hhuser', password='securepass123')
        r = self.client.get(reverse('household_list'))
        self.assertEqual(r.status_code, 200)
        d = self.client.get(reverse('household_detail', args=[self.hh.pk]))
        self.assertEqual(d.status_code, 200)

    def test_household_add_redirects_to_detail(self):
        self.client.login(username='hhuser', password='securepass123')
        r = self.client.post(
            reverse('household_add'),
            {
                'house_number': '20',
                'street': 'Lake Rd',
                'purok_sitio': 'P2',
                'notes': '',
            },
        )
        self.assertEqual(r.status_code, 302)
        self.assertTrue(Household.objects.filter(street='Lake Rd').exists())


class PrintViewSmokeTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(
            username='printer',
            password='securepass123',
        )
        self.resident = Resident.objects.create(
            first_name='Print',
            last_name='Me',
            date_of_birth=date(1970, 1, 1),
            gender='male',
            civil_status='married',
            status='active',
            is_active=True,
        )

    def test_print_endpoints_200(self):
        self.client.login(username='printer', password='securepass123')
        urls = [
            reverse('print_clearance', args=[self.resident.pk]),
            reverse('print_resident_info', args=[self.resident.pk]),
            reverse('print_resident_list'),
            reverse('print_certificate', args=[self.resident.pk, 'medical']),
        ]
        for u in urls:
            with self.subTest(url=u):
                r = self.client.get(u)
                self.assertEqual(r.status_code, 200)
