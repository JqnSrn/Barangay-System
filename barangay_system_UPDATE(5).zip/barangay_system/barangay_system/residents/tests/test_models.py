from datetime import date
from unittest.mock import patch

from django.contrib.auth.models import User
from django.test import TestCase

from residents.models import AuditLog, Household, Resident


class HouseholdModelTests(TestCase):
    def test_str_with_address_parts(self):
        h = Household.objects.create(
            house_number='10',
            street='Rizal St.',
            purok_sitio='Purok 1',
        )
        self.assertIn('10', str(h))
        self.assertIn('Rizal', str(h))

    def test_member_count_and_head(self):
        h = Household.objects.create(street='Main St.')
        Resident.objects.create(
            first_name='Ana',
            last_name='Santos',
            date_of_birth=date(1980, 5, 1),
            gender='female',
            civil_status='married',
            household=h,
            family_role='head',
            status='active',
            is_active=True,
        )
        Resident.objects.create(
            first_name='Ben',
            last_name='Santos',
            date_of_birth=date(2010, 1, 1),
            gender='male',
            civil_status='single',
            household=h,
            family_role='child',
            status='active',
            is_active=True,
        )
        Resident.objects.create(
            first_name='Old',
            last_name='Record',
            date_of_birth=date(1950, 1, 1),
            gender='male',
            civil_status='widowed',
            household=h,
            family_role='parent',
            status='active',
            is_active=False,
        )
        self.assertEqual(h.member_count, 2)
        self.assertIsNotNone(h.head)
        self.assertEqual(h.head.first_name, 'Ana')


class ResidentModelTests(TestCase):
    def test_age_calculation(self):
        fixed_today = date(2020, 6, 15)
        with patch('residents.models.date', wraps=date) as mock_date:
            mock_date.today.return_value = fixed_today
            child = Resident(
                first_name='Kid',
                last_name='Test',
                date_of_birth=date(2010, 6, 14),
                gender='male',
                civil_status='single',
            )
            self.assertEqual(child.age, 10)

            adult = Resident(
                first_name='Adult',
                last_name='Test',
                date_of_birth=date(1995, 6, 15),
                gender='female',
                civil_status='single',
            )
            self.assertEqual(adult.age, 25)

    def test_full_name_and_initials(self):
        r = Resident.objects.create(
            first_name='juan',
            middle_name='reyes',
            last_name='dela cruz',
            suffix='Jr.',
            date_of_birth=date(1992, 3, 3),
            gender='male',
            civil_status='single',
        )
        self.assertIn('dela cruz', r.full_name.lower())
        self.assertIn('juan', r.full_name.lower())
        self.assertEqual(r.initials, 'JD')

    def test_full_address_uses_household_when_set(self):
        h = Household.objects.create(
            house_number='5',
            street='Mabini Ave.',
            purok_sitio='',
        )
        r = Resident.objects.create(
            first_name='A',
            last_name='B',
            date_of_birth=date(2000, 1, 1),
            gender='male',
            civil_status='single',
            household=h,
            house_number='99',
            street='Ignored St.',
        )
        self.assertIn('Mabini', r.full_address)

    def test_household_members_excludes_self(self):
        h = Household.objects.create(street='S')
        r1 = Resident.objects.create(
            first_name='One',
            last_name='Fam',
            date_of_birth=date(1985, 1, 1),
            gender='male',
            civil_status='married',
            household=h,
            status='active',
            is_active=True,
        )
        r2 = Resident.objects.create(
            first_name='Two',
            last_name='Fam',
            date_of_birth=date(1987, 1, 1),
            gender='female',
            civil_status='married',
            household=h,
            status='active',
            is_active=True,
        )
        qs = list(r1.household_members)
        self.assertEqual(len(qs), 1)
        self.assertEqual(qs[0].pk, r2.pk)


class AuditLogModelTests(TestCase):
    def test_str_contains_action(self):
        u = User.objects.create_user(username='auditor', password='testpass12345')
        log = AuditLog.objects.create(user=u, action='login', target='User: auditor')
        text = str(log)
        self.assertIn('login', text.lower())
        self.assertIn('auditor', text)
