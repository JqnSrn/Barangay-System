from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import reverse

from residents.models import AuditLog


class LoginLogoutTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(
            username='loginme',
            password='goodpassword123',
            first_name='Test',
        )

    def test_login_page_get(self):
        r = self.client.get(reverse('login'))
        self.assertEqual(r.status_code, 200)

    def test_login_success_redirects_dashboard(self):
        r = self.client.post(
            reverse('login'),
            {'username': 'loginme', 'password': 'goodpassword123'},
        )
        self.assertRedirects(r, reverse('dashboard'), fetch_redirect_response=False)
        self.assertTrue(
            AuditLog.objects.filter(user=self.user, action='login').exists()
        )

    def test_login_invalid_stays_on_form(self):
        r = self.client.post(
            reverse('login'),
            {'username': 'loginme', 'password': 'wrong'},
        )
        self.assertEqual(r.status_code, 200)

    def test_authenticated_login_redirects_to_dashboard(self):
        self.client.login(username='loginme', password='goodpassword123')
        r = self.client.get(reverse('login'))
        self.assertEqual(r.status_code, 302)
        self.assertEqual(r.url, reverse('dashboard'))

    def test_logout_post_clears_session(self):
        self.client.login(username='loginme', password='goodpassword123')
        r = self.client.post(reverse('logout'))
        self.assertEqual(r.status_code, 302)
        self.assertFalse('_auth_user_id' in self.client.session)
