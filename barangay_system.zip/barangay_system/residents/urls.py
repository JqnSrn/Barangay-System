from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/',                          views.dashboard,            name='dashboard'),
    path('residents/',                          views.resident_list,        name='resident_list'),
    path('residents/add/',                      views.resident_add,         name='resident_add'),
    path('residents/archived/',                 views.archived_list,        name='archived_list'),
    path('residents/<int:pk>/',                 views.resident_detail,      name='resident_detail'),
    path('residents/<int:pk>/edit/',            views.resident_edit,        name='resident_edit'),
    path('residents/<int:pk>/archive/',         views.resident_archive,     name='resident_archive'),
    path('residents/<int:pk>/restore/',         views.resident_restore,     name='resident_restore'),
    path('residents/<int:pk>/print/clearance/', views.print_clearance,      name='print_clearance'),
    path('residents/<int:pk>/print/info/',      views.print_resident_info,  name='print_resident_info'),
    path('residents/print/list/',               views.print_resident_list,  name='print_resident_list'),
]
